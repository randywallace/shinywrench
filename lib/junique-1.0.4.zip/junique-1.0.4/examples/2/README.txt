This one adds support both for command line arguments
and message exchange between application instances.

Try to run this:

java -Djava.ext.dirs=../../ -jar textpad.jar README.txt

(otherwise launch run1.bat)

While the application is running, try the following:

java -Djava.ext.dirs=../../ -jar textpad.jar LEGGIMI.txt

(otherwise launch run2.bat)
